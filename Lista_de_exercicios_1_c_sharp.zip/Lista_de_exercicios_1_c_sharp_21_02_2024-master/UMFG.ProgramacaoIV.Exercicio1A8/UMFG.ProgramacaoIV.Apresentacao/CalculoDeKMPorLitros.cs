﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UMFG.ProgramacaoIV.Apresentacao
{
    internal class CalculoDeKMPorLitros
    {
        private double DistanciaPercorrida { set; get; }
        private double QuantidadeDeLitrosGastos { set; get; }
        private double MediaDeKMPorLitro { set; get; }

        public void CalcularMedia(double distanciaPercorrida, double quantidadeDeLitrosGastos) 
        {
            DistanciaPercorrida = distanciaPercorrida;
            QuantidadeDeLitrosGastos = quantidadeDeLitrosGastos;
            MediaDeKMPorLitro = distanciaPercorrida / quantidadeDeLitrosGastos;
            MediaDeKMPorLitro = Math.Round(MediaDeKMPorLitro, 2);
            Console.WriteLine("+----------------------------------------------+");
            Console.WriteLine("| A média é de " + MediaDeKMPorLitro + " KMs/Litro");
        }
    }
}
