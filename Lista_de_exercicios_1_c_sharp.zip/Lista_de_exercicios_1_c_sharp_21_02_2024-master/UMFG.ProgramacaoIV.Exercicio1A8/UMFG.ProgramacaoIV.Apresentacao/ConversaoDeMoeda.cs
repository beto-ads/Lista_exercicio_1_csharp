﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UMFG.ProgramacaoIV.Apresentacao
{
    internal class ConversaoDeMoeda
    {
        public double ValorReal { get; set; }
        public double ValorDolar { get; set; }
        public double ValorUsuario { get; set; }
        public double ValorConvertido { get; set; }

        public void ConverterRealParaDolar(double valorUsuario) 
        {
            ValorDolar = 0.193259;
            ValorUsuario = valorUsuario;
            ValorConvertido = ValorUsuario * ValorDolar;
            ValorConvertido = Math.Round(ValorConvertido, 2);
            Console.WriteLine("+----------------------------------------------+");
            Console.WriteLine("| Conversão = US$" + ValorConvertido);
        }

        public void ConverterDolarParaReal(double valorUsuario)
        {
            ValorReal = 5.22;
            ValorUsuario = valorUsuario;
            ValorConvertido = ValorUsuario * ValorReal;
            ValorConvertido = Math.Round(ValorConvertido, 2);
            Console.WriteLine("+----------------------------------------------+");
            Console.WriteLine("| Conversão = R$" + ValorCovertido);
        }
    }
}
